import { useState, useEffect } from 'react';

// Mock course data
const mockCourses = [
  {
    id: '1',
    title: 'Introduction to Web Development',
    description: 'Learn the fundamentals of HTML, CSS, and JavaScript to build modern websites.',
    instructor: {
      id: '101',
      name: 'Dr. Sarah Johnson',
      avatar: null,
      bio: 'Senior Software Engineer with 10+ years of experience',
    },
    thumbnail: null,
    category: 'Development',
    level: 'Beginner',
    duration: '8 weeks',
    lessons: 24,
    rating: 4.8,
    students: 1250,
    price: 49.99,
    isFree: false,
    tags: ['HTML', 'CSS', 'JavaScript', 'Web'],
    syllabus: [
      { week: 1, title: 'HTML Fundamentals', lessons: 4 },
      { week: 2, title: 'CSS Basics', lessons: 4 },
      { week: 3, title: 'Responsive Design', lessons: 4 },
      { week: 4, title: 'JavaScript Introduction', lessons: 4 },
      { week: 5, title: 'DOM Manipulation', lessons: 4 },
      { week: 6, title: 'Event Handling', lessons: 4 },
    ],
  },
  {
    id: '2',
    title: 'Data Science with Python',
    description: 'Master data analysis, visualization, and machine learning with Python.',
    instructor: {
      id: '102',
      name: 'Prof. Michael Chen',
      avatar: null,
      bio: 'Data Scientist and AI Researcher',
    },
    thumbnail: null,
    category: 'Data Science',
    level: 'Intermediate',
    duration: '12 weeks',
    lessons: 36,
    rating: 4.9,
    students: 2100,
    price: 79.99,
    isFree: false,
    tags: ['Python', 'Data Analysis', 'Machine Learning', 'Pandas'],
    syllabus: [],
  },
  {
    id: '3',
    title: 'Digital Marketing Fundamentals',
    description: 'Learn SEO, social media marketing, and content strategy.',
    instructor: {
      id: '103',
      name: 'Emma Williams',
      avatar: null,
      bio: 'Marketing Director with expertise in digital campaigns',
    },
    thumbnail: null,
    category: 'Marketing',
    level: 'Beginner',
    duration: '6 weeks',
    lessons: 18,
    rating: 4.7,
    students: 890,
    price: 0,
    isFree: true,
    tags: ['SEO', 'Social Media', 'Content Marketing'],
    syllabus: [],
  },
  {
    id: '4',
    title: 'UI/UX Design Principles',
    description: 'Create beautiful and user-friendly interfaces with modern design principles.',
    instructor: {
      id: '104',
      name: 'Alex Rivera',
      avatar: null,
      bio: 'Lead Designer at top tech companies',
    },
    thumbnail: null,
    category: 'Design',
    level: 'Intermediate',
    duration: '10 weeks',
    lessons: 30,
    rating: 4.8,
    students: 1560,
    price: 59.99,
    isFree: false,
    tags: ['UI', 'UX', 'Figma', 'Design Systems'],
    syllabus: [],
  },
];

export const useCourses = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Simulate API fetch
    const fetchCourses = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 300));
        setCourses(mockCourses);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchCourses();
  }, []);

  const getCourseById = (id) => {
    return courses.find(course => course.id === id);
  };

  const getCoursesByCategory = (category) => {
    return courses.filter(course => course.category === category);
  };

  const searchCourses = (query) => {
    const lowercaseQuery = query.toLowerCase();
    return courses.filter(
      course =>
        course.title.toLowerCase().includes(lowercaseQuery) ||
        course.description.toLowerCase().includes(lowercaseQuery) ||
        course.tags.some(tag => tag.toLowerCase().includes(lowercaseQuery))
    );
  };

  const filterCourses = ({ category, level, price }) => {
    return courses.filter(course => {
      if (category && course.category !== category) return false;
      if (level && course.level !== level) return false;
      if (price === 'free' && !course.isFree) return false;
      if (price === 'paid' && course.isFree) return false;
      return true;
    });
  };

  return {
    courses,
    loading,
    error,
    getCourseById,
    getCoursesByCategory,
    searchCourses,
    filterCourses,
  };
};

export const getAllCategories = () => {
  const categories = [...new Set(mockCourses.map(c => c.category))];
  return categories;
};

export const getAllLevels = () => {
  return ['Beginner', 'Intermediate', 'Advanced'];
};
