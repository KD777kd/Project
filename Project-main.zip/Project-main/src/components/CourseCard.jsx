import { Link } from 'react-router-dom';

const CourseCard = ({ course }) => {
  const {
    id,
    title,
    description,
    instructor,
    category,
    level,
    duration,
    lessons,
    rating,
    students,
    price,
    isFree,
    tags,
  } = course;

  return (
    <article className="card group hover:shadow-md transition-shadow duration-200" aria-labelledby={`course-title-${id}`}>
      {/* Thumbnail */}
      <div className="relative h-48 bg-gradient-to-br from-primary-100 to-primary-200 overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center">
          <svg className="w-16 h-16 text-primary-300" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M12 3L1 9l11 6 9-4.91V17h2V9M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82z" />
          </svg>
        </div>
        
        {/* Category Badge */}
        <div className="absolute top-3 left-3">
          <span className="badge badge-primary">{category}</span>
        </div>
        
        {/* Price Badge */}
        <div className="absolute top-3 right-3">
          {isFree ? (
            <span className="badge badge-success">Free</span>
          ) : (
            <span className="bg-white px-3 py-1 rounded-full text-sm font-semibold text-secondary-900">
              ${price}
            </span>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        <h3 id={`course-title-${id}`} className="text-lg font-semibold text-secondary-900 mb-2 line-clamp-2 group-hover:text-primary-600 transition-colors">
          <Link to={`/courses/${id}`}>
            <span className="sr-only">View course: </span>
            {title}
          </Link>
        </h3>
        
        <p className="text-secondary-600 text-sm mb-4 line-clamp-2">
          {description}
        </p>

        {/* Instructor */}
        <div className="flex items-center space-x-2 mb-4">
          <div className="w-8 h-8 rounded-full bg-secondary-200 flex items-center justify-center">
            <span className="text-secondary-600 text-sm font-medium">
              {instructor.name.charAt(0)}
            </span>
          </div>
          <span className="text-sm text-secondary-700">{instructor.name}</span>
        </div>

        {/* Meta Info */}
        <div className="flex items-center justify-between text-sm text-secondary-500 mb-4">
          <div className="flex items-center space-x-4">
            <span className="flex items-center" aria-label={`${duration} duration`}>
              <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {duration}
            </span>
            <span className="flex items-center" aria-label={`${lessons} lessons`}>
              <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
              {lessons}
            </span>
          </div>
          <div className="flex items-center" aria-label={`${rating} out of 5 stars`}>
            <svg className="w-4 h-4 text-yellow-400 mr-1" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
              <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
            </svg>
            <span className="font-medium">{rating}</span>
            <span className="text-secondary-400 ml-1">({students})</span>
          </div>
        </div>

        {/* Level and Tags */}
        <div className="flex items-center justify-between">
          <span className="text-xs text-secondary-500 bg-secondary-100 px-2 py-1 rounded">
            {level}
          </span>
          {tags && tags.length > 0 && (
            <div className="flex space-x-1">
              {tags.slice(0, 2).map((tag, index) => (
                <span key={index} className="text-xs text-primary-600 bg-primary-50 px-2 py-1 rounded">
                  {tag}
                </span>
              ))}
              {tags.length > 2 && (
                <span className="text-xs text-secondary-500">+{tags.length - 2}</span>
              )}
            </div>
          )}
        </div>

        {/* CTA Button */}
        <Link
          to={`/courses/${id}`}
          className="mt-4 block w-full btn btn-primary text-center"
          aria-label={`Enroll in ${title}`}
        >
          View Course
        </Link>
      </div>
    </article>
  );
};

export default CourseCard;
