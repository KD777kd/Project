import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import CoursesPage from './pages/CoursesPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';

// Placeholder components for additional pages
const AboutPage = () => (
  <main id="main-content" className="min-h-screen bg-secondary-50 py-16">
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
      <h1 className="text-4xl font-bold text-secondary-900 mb-4">About EduLearn</h1>
      <p className="text-lg text-secondary-600">
        EduLearn is a comprehensive digital learning platform dedicated to providing high-quality 
        educational experiences to students, educators, and lifelong learners worldwide.
      </p>
    </div>
  </main>
);

const InstructorsPage = () => (
  <main id="main-content" className="min-h-screen bg-secondary-50 py-16">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <h1 className="text-4xl font-bold text-secondary-900 mb-4 text-center">Our Instructors</h1>
      <p className="text-lg text-secondary-600 text-center mb-12">
        Learn from industry experts and academic professionals
      </p>
    </div>
  </main>
);

const CourseDetailPage = () => (
  <main id="main-content" className="min-h-screen bg-secondary-50 py-16">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <h1 className="text-4xl font-bold text-secondary-900 mb-4">Course Details</h1>
      <p className="text-secondary-600">Course content will be displayed here</p>
    </div>
  </main>
);

const NotFoundPage = () => (
  <main id="main-content" className="min-h-screen bg-secondary-50 flex items-center justify-center">
    <div className="text-center">
      <h1 className="text-6xl font-bold text-primary-600 mb-4">404</h1>
      <h2 className="text-2xl font-semibold text-secondary-900 mb-4">Page Not Found</h2>
      <p className="text-secondary-600 mb-8">
        The page you're looking for doesn't exist or has been moved.
      </p>
      <a href="/" className="btn btn-primary">Go Home</a>
    </div>
  </main>
);

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-grow">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/courses" element={<CoursesPage />} />
          <Route path="/courses/:id" element={<CourseDetailPage />} />
          <Route path="/instructors" element={<InstructorsPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </div>
      <Footer />
    </div>
  );
}

export default App;
