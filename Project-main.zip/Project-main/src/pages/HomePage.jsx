import { Link } from 'react-router-dom';
import { useCourses } from '../hooks/useCourses';
import CourseCard from '../components/CourseCard';

const HomePage = () => {
  const { courses, loading } = useCourses();
  const featuredCourses = courses.slice(0, 3);

  const stats = [
    { label: 'Active Students', value: '50K+' },
    { label: 'Courses Available', value: '200+' },
    { label: 'Expert Instructors', value: '100+' },
    { label: 'Completion Rate', value: '85%' },
  ];

  const features = [
    {
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
        </svg>
      ),
      title: 'Learn Anywhere',
      description: 'Access your courses from any device, anytime. Learn at your own pace with flexible scheduling.',
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
        </svg>
      ),
      title: 'Expert-Led Content',
      description: 'Learn from industry professionals and academic experts with real-world experience.',
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
        </svg>
      ),
      title: 'Certified Programs',
      description: 'Earn recognized certificates upon completion to boost your career prospects.',
    },
    {
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      ),
      title: 'Community Support',
      description: 'Join a global community of learners, participate in discussions and get help when needed.',
    },
  ];

  return (
    <main id="main-content">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-600 via-primary-700 to-primary-800 text-white" aria-labelledby="hero-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 id="hero-heading" className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                Unlock Your Potential with{' '}
                <span className="text-primary-200">Online Learning</span>
              </h1>
              <p className="text-lg md:text-xl text-primary-100 mb-8 max-w-lg">
                Access thousands of courses from expert instructors. Learn new skills, advance your career, and achieve your goals at your own pace.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/courses" className="btn bg-white text-primary-700 hover:bg-primary-50 font-semibold px-8 py-3">
                  Explore Courses
                </Link>
                <Link to="/register" className="btn border-2 border-white text-white hover:bg-white/10 font-semibold px-8 py-3">
                  Start Learning Free
                </Link>
              </div>
            </div>
            <div className="hidden md:block" aria-hidden="true">
              <svg className="w-full h-auto opacity-90" viewBox="0 0 400 300" fill="none">
                <rect x="50" y="50" width="300" height="200" rx="12" fill="white" fillOpacity="0.1" />
                <rect x="70" y="70" width="260" height="140" rx="8" fill="white" fillOpacity="0.15" />
                <circle cx="200" cy="140" r="40" fill="white" fillOpacity="0.2" />
                <rect x="100" y="230" width="80" height="12" rx="6" fill="white" fillOpacity="0.3" />
                <rect x="220" y="230" width="80" height="12" rx="6" fill="white" fillOpacity="0.2" />
              </svg>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-white py-12 border-b border-secondary-200" aria-label="Platform statistics">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary-600 mb-2">{stat.value}</div>
                <div className="text-secondary-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Courses */}
      <section className="py-16 bg-secondary-50" aria-labelledby="featured-courses-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 id="featured-courses-heading" className="text-3xl font-bold text-secondary-900 mb-2">
                Featured Courses
              </h2>
              <p className="text-secondary-600">Discover our most popular courses</p>
            </div>
            <Link to="/courses" className="btn btn-outline hidden sm:inline-flex">
              View All Courses
              <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </Link>
          </div>

          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6" role="status" aria-label="Loading courses">
              {[1, 2, 3].map((i) => (
                <div key={i} className="card animate-pulse">
                  <div className="h-48 bg-secondary-200" />
                  <div className="p-5 space-y-4">
                    <div className="h-6 bg-secondary-200 rounded w-3/4" />
                    <div className="h-4 bg-secondary-200 rounded w-full" />
                    <div className="h-4 bg-secondary-200 rounded w-2/3" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredCourses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          )}

          <div className="mt-8 text-center sm:hidden">
            <Link to="/courses" className="btn btn-outline">
              View All Courses
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white" aria-labelledby="features-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 id="features-heading" className="text-3xl font-bold text-secondary-900 mb-4">
              Why Choose EduLearn?
            </h2>
            <p className="text-secondary-600 max-w-2xl mx-auto">
              We provide a comprehensive learning experience designed to help you succeed
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center p-6 rounded-xl hover:bg-secondary-50 transition-colors">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 text-primary-600 rounded-xl mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-lg font-semibold text-secondary-900 mb-2">{feature.title}</h3>
                <p className="text-secondary-600 text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-secondary-900 text-white" aria-labelledby="cta-heading">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 id="cta-heading" className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Start Learning?
          </h2>
          <p className="text-lg text-secondary-300 mb-8 max-w-2xl mx-auto">
            Join thousands of students already learning on EduLearn. Create your free account today and start your learning journey.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register" className="btn bg-primary-600 text-white hover:bg-primary-700 font-semibold px-8 py-3">
              Get Started Free
            </Link>
            <Link to="/about" className="btn border-2 border-white text-white hover:bg-white/10 font-semibold px-8 py-3">
              Learn More
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
};

export default HomePage;
