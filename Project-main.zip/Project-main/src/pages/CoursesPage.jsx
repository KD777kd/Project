import { useState } from 'react';
import { useCourses, getAllCategories, getAllLevels } from '../hooks/useCourses';
import CourseCard from '../components/CourseCard';

const CoursesPage = () => {
  const { courses, loading, searchCourses, filterCourses } = useCourses();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedLevel, setSelectedLevel] = useState('');
  const [priceFilter, setPriceFilter] = useState('');

  const categories = getAllCategories();
  const levels = getAllLevels();

  const handleSearch = (e) => {
    e.preventDefault();
  };

  const filteredCourses = searchQuery
    ? searchCourses(searchQuery)
    : filterCourses({
        category: selectedCategory || undefined,
        level: selectedLevel || undefined,
        price: priceFilter || undefined,
      });

  return (
    <main id="main-content" className="min-h-screen bg-secondary-50">
      {/* Page Header */}
      <section className="bg-white border-b border-secondary-200" aria-labelledby="page-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h1 id="page-heading" className="text-3xl md:text-4xl font-bold text-secondary-900 mb-4">
            Browse Our Courses
          </h1>
          <p className="text-secondary-600 max-w-2xl">
            Explore our comprehensive catalog of courses designed to help you achieve your learning goals.
          </p>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="bg-white border-b border-secondary-200 sticky top-16 z-30" aria-label="Course filters">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4">
            {/* Search Input */}
            <div className="flex-1">
              <label htmlFor="course-search" className="sr-only">
                Search courses
              </label>
              <div className="relative">
                <input
                  id="course-search"
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search courses..."
                  className="input pl-10"
                  aria-describedby="search-help"
                />
                <svg
                  className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-secondary-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <span id="search-help" className="sr-only">
                Type to search courses by title, description, or tags
              </span>
            </div>

            {/* Category Filter */}
            <div>
              <label htmlFor="category-filter" className="sr-only">
                Filter by category
              </label>
              <select
                id="category-filter"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="input"
              >
                <option value="">All Categories</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Level Filter */}
            <div>
              <label htmlFor="level-filter" className="sr-only">
                Filter by level
              </label>
              <select
                id="level-filter"
                value={selectedLevel}
                onChange={(e) => setSelectedLevel(e.target.value)}
                className="input"
              >
                <option value="">All Levels</option>
                {levels.map((level) => (
                  <option key={level} value={level}>
                    {level}
                  </option>
                ))}
              </select>
            </div>

            {/* Price Filter */}
            <div>
              <label htmlFor="price-filter" className="sr-only">
                Filter by price
              </label>
              <select
                id="price-filter"
                value={priceFilter}
                onChange={(e) => setPriceFilter(e.target.value)}
                className="input"
              >
                <option value="">All Prices</option>
                <option value="free">Free</option>
                <option value="paid">Paid</option>
              </select>
            </div>

            {/* Clear Filters Button */}
            {(searchQuery || selectedCategory || selectedLevel || priceFilter) && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('');
                  setSelectedLevel('');
                  setPriceFilter('');
                }}
                className="btn btn-secondary whitespace-nowrap"
              >
                Clear Filters
              </button>
            )}
          </form>
        </div>
      </section>

      {/* Course Grid */}
      <section className="py-8" aria-label="Course results">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Results Count */}
          <div className="mb-6 flex justify-between items-center">
            <p className="text-secondary-600" role="status" aria-live="polite">
              {loading ? (
                'Loading courses...'
              ) : (
                <>
                  Showing <span className="font-semibold">{filteredCourses.length}</span> course
                  {filteredCourses.length !== 1 ? 's' : ''}
                </>
              )}
            </p>
          </div>

          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6" role="status" aria-label="Loading courses">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="card animate-pulse">
                  <div className="h-48 bg-secondary-200" />
                  <div className="p-5 space-y-4">
                    <div className="h-6 bg-secondary-200 rounded w-3/4" />
                    <div className="h-4 bg-secondary-200 rounded w-full" />
                    <div className="h-4 bg-secondary-200 rounded w-2/3" />
                  </div>
                </div>
              ))}
            </div>
          ) : filteredCourses.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCourses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16" role="status">
              <svg
                className="w-16 h-16 text-secondary-300 mx-auto mb-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
              <h3 className="text-lg font-semibold text-secondary-900 mb-2">No courses found</h3>
              <p className="text-secondary-600 mb-4">
                Try adjusting your search or filters to find what you're looking for.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('');
                  setSelectedLevel('');
                  setPriceFilter('');
                }}
                className="btn btn-primary"
              >
                Clear All Filters
              </button>
            </div>
          )}
        </div>
      </section>
    </main>
  );
};

export default CoursesPage;
