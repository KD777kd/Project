import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';

const DashboardPage = () => {
  const { user, isStudent, isInstructor, isAdmin } = useAuth();

  const enrolledCourses = [
    { id: '1', title: 'Introduction to Web Development', progress: 65 },
    { id: '2', title: 'Data Science with Python', progress: 30 },
  ];

  const recentActivity = [
    { type: 'completed', course: 'HTML Fundamentals', date: '2 hours ago' },
    { type: 'started', course: 'CSS Basics', date: '1 day ago' },
    { type: 'enrolled', course: 'JavaScript Introduction', date: '3 days ago' },
  ];

  return (
    <main id="main-content" className="min-h-screen bg-secondary-50">
      {/* Page Header */}
      <section className="bg-white border-b border-secondary-200" aria-labelledby="page-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 id="page-heading" className="text-2xl md:text-3xl font-bold text-secondary-900 mb-2">
                Welcome back, {user?.name}!
              </h1>
              <p className="text-secondary-600">
                {isStudent && "Continue your learning journey"}
                {isInstructor && "Manage your courses and students"}
                {isAdmin && "Admin dashboard"}
              </p>
            </div>
            <Link to="/courses" className="btn btn-primary hidden sm:inline-flex">
              Browse Courses
            </Link>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Enrolled Courses */}
            {isStudent && (
              <section aria-labelledby="enrolled-courses-heading">
                <div className="flex items-center justify-between mb-4">
                  <h2 id="enrolled-courses-heading" className="text-xl font-bold text-secondary-900">
                    My Courses
                  </h2>
                  <Link to="/dashboard/courses" className="text-sm text-primary-600 hover:text-primary-700 font-medium">
                    View all
                  </Link>
                </div>
                <div className="space-y-4">
                  {enrolledCourses.map((course) => (
                    <div key={course.id} className="card p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-semibold text-secondary-900 mb-1">{course.title}</h3>
                          <p className="text-sm text-secondary-500">In Progress</p>
                        </div>
                        <span className="badge badge-primary">{course.progress}%</span>
                      </div>
                      <div className="w-full bg-secondary-200 rounded-full h-2" role="progressbar" aria-valuenow={course.progress} aria-valuemin={0} aria-valuemax={100}>
                        <div
                          className="bg-primary-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${course.progress}%` }}
                        />
                      </div>
                      <Link
                        to={`/courses/${course.id}`}
                        className="mt-3 inline-block text-sm text-primary-600 hover:text-primary-700 font-medium"
                      >
                        Continue Learning →
                      </Link>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Instructor Stats */}
            {isInstructor && (
              <section aria-labelledby="instructor-stats-heading">
                <h2 id="instructor-stats-heading" className="text-xl font-bold text-secondary-900 mb-4">
                  Your Courses
                </h2>
                <div className="grid sm:grid-cols-3 gap-4 mb-6">
                  <div className="card p-4 text-center">
                    <div className="text-2xl font-bold text-primary-600">3</div>
                    <div className="text-sm text-secondary-600">Active Courses</div>
                  </div>
                  <div className="card p-4 text-center">
                    <div className="text-2xl font-bold text-primary-600">1.2K</div>
                    <div className="text-sm text-secondary-600">Total Students</div>
                  </div>
                  <div className="card p-4 text-center">
                    <div className="text-2xl font-bold text-primary-600">4.8</div>
                    <div className="text-sm text-secondary-600">Avg Rating</div>
                  </div>
                </div>
              </section>
            )}

            {/* Recent Activity */}
            <section aria-labelledby="activity-heading">
              <h2 id="activity-heading" className="text-xl font-bold text-secondary-900 mb-4">
                Recent Activity
              </h2>
              <div className="card">
                <div className="divide-y divide-secondary-200">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="p-4 flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        activity.type === 'completed' ? 'bg-green-100 text-green-600' :
                        activity.type === 'started' ? 'bg-blue-100 text-blue-600' :
                        'bg-purple-100 text-purple-600'
                      }`}>
                        {activity.type === 'completed' && (
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                        {activity.type === 'started' && (
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        )}
                        {activity.type === 'enrolled' && (
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                          </svg>
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-secondary-900">
                          {activity.type === 'completed' && 'Completed'}
                          {activity.type === 'started' && 'Started'}
                          {activity.type === 'enrolled' && 'Enrolled in'}
                          {' '}{activity.course}
                        </p>
                        <p className="text-xs text-secondary-500">{activity.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <aside className="space-y-6" aria-label="Dashboard sidebar">
            {/* Profile Card */}
            <div className="card p-6 text-center">
              <div className="w-20 h-20 rounded-full bg-primary-100 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-primary-600">
                  {user?.name?.charAt(0).toUpperCase()}
                </span>
              </div>
              <h3 className="font-semibold text-secondary-900 mb-1">{user?.name}</h3>
              <p className="text-sm text-secondary-500 mb-4">{user?.email}</p>
              <span className="badge badge-primary capitalize">{user?.role}</span>
              <Link to="/dashboard/profile" className="mt-4 block btn btn-outline text-sm">
                Edit Profile
              </Link>
            </div>

            {/* Quick Links */}
            <div className="card p-4">
              <h3 className="font-semibold text-secondary-900 mb-3">Quick Links</h3>
              <nav className="space-y-2" aria-label="Quick links">
                <Link to="/dashboard/settings" className="block text-sm text-secondary-600 hover:text-primary-600 py-2">
                  Account Settings
                </Link>
                <Link to="/dashboard/achievements" className="block text-sm text-secondary-600 hover:text-primary-600 py-2">
                  Achievements
                </Link>
                <Link to="/dashboard/certificates" className="block text-sm text-secondary-600 hover:text-primary-600 py-2">
                  Certificates
                </Link>
                <Link to="/help" className="block text-sm text-secondary-600 hover:text-primary-600 py-2">
                  Help Center
                </Link>
              </nav>
            </div>

            {/* Learning Stats */}
            {isStudent && (
              <div className="card p-4">
                <h3 className="font-semibold text-secondary-900 mb-3">Learning Stats</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-secondary-600">Courses Completed</span>
                    <span className="font-semibold text-secondary-900">2</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-secondary-600">Hours Learned</span>
                    <span className="font-semibold text-secondary-900">24</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-secondary-600">Certificates</span>
                    <span className="font-semibold text-secondary-900">1</span>
                  </div>
                </div>
              </div>
            )}
          </aside>
        </div>
      </div>
    </main>
  );
};

export default DashboardPage;
