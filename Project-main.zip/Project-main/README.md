# EduLearn - Digital Learning Platform

## Overview

EduLearn is a comprehensive, professional educational website designed to deliver high-quality digital learning experiences to a global audience of students, educators, and lifelong learners. The platform prioritizes accessibility, intuitive navigation, and pedagogical effectiveness while maintaining a modern, visually cohesive interface.

## Features

### Core Functionality
- **Course Catalog**: Browse and search courses with advanced filtering options
- **User Authentication**: Secure registration and login with role-based access control
- **Learning Dashboard**: Personalized learning pathways with progress tracking
- **Responsive Design**: Optimized for desktop, tablet, and mobile devices
- **Accessibility**: WCAG 2.2 AA compliant with screen reader support

### User Roles
- **Students**: Enroll in courses, track progress, earn certificates
- **Instructors**: Create and manage courses, monitor student engagement
- **Administrators**: Full platform management and analytics

## Technology Stack

### Frontend
- **React 19** - Modern UI library with hooks
- **React Router DOM** - Client-side routing
- **Tailwind CSS** - Utility-first styling framework
- **Vite** - Fast build tool and dev server

### Styling & Design
- Custom color palette (Primary, Secondary, Accent)
- Inter font family for optimal readability
- Component-based design system
- Mobile-first responsive approach

## Project Structure

```
/workspace
├── index.html              # HTML entry point with SEO meta tags
├── package.json            # Dependencies and scripts
├── vite.config.js          # Vite configuration
├── tailwind.config.js      # Tailwind CSS customization
├── postcss.config.js       # PostCSS configuration
├── src/
│   ├── main.jsx            # React entry point
│   ├── App.jsx             # Main application component with routes
│   ├── index.css           # Global styles and Tailwind directives
│   ├── components/
│   │   ├── Navbar.jsx      # Navigation header with mobile menu
│   │   ├── Footer.jsx      # Site footer with links
│   │   └── CourseCard.jsx  # Reusable course card component
│   ├── pages/
│   │   ├── HomePage.jsx    # Landing page with hero and features
│   │   ├── CoursesPage.jsx # Course catalog with filters
│   │   ├── LoginPage.jsx   # User authentication
│   │   ├── RegisterPage.jsx# User registration
│   │   └── DashboardPage.jsx# Personalized user dashboard
│   ├── context/
│   │   └── AuthContext.jsx # Authentication state management
│   ├── hooks/
│   │   └── useCourses.js   # Course data fetching hook
│   └── utils/              # Utility functions
└── public/                 # Static assets
```

## Getting Started

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Run linter
npm run lint

# Format code
npm run format
```

### Development Server

The development server runs on `http://localhost:3000` by default.

## Accessibility Features

- Semantic HTML structure
- ARIA labels and roles throughout
- Skip navigation link for keyboard users
- Focus visible indicators
- Color contrast ratios meeting WCAG AA standards
- Screen reader announcements for dynamic content
- Keyboard navigable interface

## Responsive Breakpoints

- Mobile: < 640px
- Tablet: 640px - 1024px
- Desktop: > 1024px

## Color Palette

### Primary (Blue)
- Used for primary actions, links, and branding
- Range: 50 (lightest) to 900 (darkest)

### Secondary (Gray)
- Used for text, backgrounds, and borders
- Range: 50 (lightest) to 900 (darkest)

### Accent (Red)
- Used for alerts and important highlights
- Range: 50 (lightest) to 900 (darkest)

## Component Library

### Buttons
- `.btn-primary` - Primary action buttons
- `.btn-secondary` - Secondary actions
- `.btn-outline` - Outlined style buttons

### Cards
- `.card` - Base card container
- `.card-header` - Card header section
- `.card-body` - Card content area

### Forms
- `.input` - Text input fields
- `.label` - Form labels
- Built-in validation states

### Badges
- `.badge-primary` - Primary status badges
- `.badge-success` - Success indicators
- `.badge-warning` - Warning indicators

## API Integration Points

The platform is designed for easy backend integration:

1. **Authentication**: Replace mock auth in `AuthContext.jsx`
2. **Course Data**: Connect `useCourses.js` to your API
3. **User Progress**: Implement progress tracking endpoints
4. **Payment Processing**: Integrate Stripe/PayPal for paid courses

## Security Considerations

- Input validation on all forms
- CSRF protection ready
- XSS prevention through React's escaping
- Secure password handling (to be implemented with backend)
- GDPR/CCPA compliance structure in place

## Performance Optimization

- Code splitting via React Router
- Lazy loading for route components
- Image optimization placeholders
- CSS purging via Tailwind
- Gzip compression ready

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Deployment

### Production Build

```bash
npm run build
```

Output is generated in the `dist/` directory.

### Environment Variables

Create a `.env` file for environment-specific configuration:

```
VITE_API_URL=https://api.edulearn.com
VITE_APP_NAME=EduLearn
```

## Contributing

1. Follow the existing code style
2. Write meaningful commit messages
3. Test accessibility features
4. Ensure responsive design works across breakpoints

## License

ISC License

## Support

For questions or issues, please contact the development team.

---

*Built with React, Tailwind CSS, and Vite*
